﻿using Core.Interfaces;
using Core.Models.User;
using Domain;
using Infrastructure.Database;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace Infrastructure.Services
{
    public class userService : IUser
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _config;
        private readonly IEmailService _emailService;
        private readonly IJwtService _jwtService;
        

        public userService(AppDbContext context, IConfiguration config, IEmailService emailService,IJwtService jwtService)
        {
            _context = context;
            _config = config;
            _emailService = emailService;
            _jwtService = jwtService;

        }
        public async Task<userRegistrationDto> userRegistration(userRegistrationDto dto)
        {
            var existingUser = _context.Users.Where(u => u.Email == dto.Email).FirstOrDefault();
            if (existingUser != null)
            {
                return null;
            }

            var uniqueUserName = $"EC_{dto.LastName.ToUpper()}{dto.FirstName.ToUpper().Substring(0,1)}{dto.Dob.ToString("ddMMyy")}";
            var uniquePassword = GeneratePassword();

            var user = new User
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                UserType = dto.UserType,
                Dob = dto.Dob,
                Mobile = dto.Mobile,
                AddressLine1 = dto.AddressLine1,
                AddressLine2 = dto.AddressLine2,
                zipcode = dto.zipcode,
                StateId = dto.StateId,
                CountryId = dto.CountryId,
                ProfileImage = dto.ProfileImage,
                UserName = uniqueUserName,
                Password = HashPassword(uniquePassword)
            };
            
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            await _emailService.SendRegistrationEmailAsync(dto.Email, $"Welcome! {dto.FirstName}",
             $"use the below credentials to log into your account\n" +
             $"UserName:\t{uniqueUserName}\nPassword:\t{uniquePassword}");
            return await Task.FromResult(dto);
           
        }


        public async Task<bool> userLogin(userLoginDto dto)
        {
            var exitingUser = _context.Users.Where(u => u.UserName == dto.Username).FirstOrDefault();
            if (exitingUser == null)
            {
                return false;
            }
            if (VerifyPassword(dto.Password, exitingUser.Password))
            {
                var otp = GenerateOtp();
                var otpRegistration = _context.OneTimePassword.Where(u => u.userId == exitingUser.Id).FirstOrDefault();
                if (otpRegistration != null)
                {
                    otpRegistration.LastestOtp = otp;
                    await _context.SaveChangesAsync();
                    await _emailService.SendRegistrationEmailAsync(exitingUser.Email, $"Hello! {exitingUser.FirstName}",
                    $"Your one time password is \n" +
                    $"{otp}");
                    return true;
                }
                var newOtpRegistration = new OneTimePassword();
                newOtpRegistration.userId = exitingUser.Id;
                newOtpRegistration.LastestOtp = otp;
                await _context.OneTimePassword.AddAsync(newOtpRegistration);
                await _context.SaveChangesAsync();
                await _emailService.SendRegistrationEmailAsync(exitingUser.Email, $"Hello! {exitingUser.FirstName}",
                $"Your one time password is \n" +
                $"{otp}");
                return true;
            }
            return false;
        }

        public async Task<string> userVerification(OtpVerficationDto dto)
        {
            var exitingUser = await _context.Users.Where(u => u.UserName == dto.Username).FirstOrDefaultAsync();

            var user = await _context.OneTimePassword.Where(u => u.userId == exitingUser.Id).FirstOrDefaultAsync();

            var role = exitingUser.UserType == 1 ? "Admin" : "Role";
           
            if(user.LastestOtp == dto.Otp)
            {
                return await Task.FromResult(_jwtService.GenerateToken(exitingUser.UserName, exitingUser.Id,new List<string> { role}));
            }
            return "unsuccessful";
        }

        public static string GeneratePassword(int length = 8)
        {
            const string validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder result = new StringBuilder();
            Random random = new Random();

            while (0 < length--)
            {
                result.Append(validChars[random.Next(validChars.Length)]);
            }

            return result.ToString();
        }

        public static string HashPassword(string plainTextPassword)
        {
            // Hash the password with a salt
            return BCrypt.Net.BCrypt.HashPassword(plainTextPassword);
        }

        public bool VerifyPassword(string plainTextPassword, string hashedPassword)
        {
            // Verify the password
            return BCrypt.Net.BCrypt.Verify(plainTextPassword, hashedPassword);
        }

        public static string GenerateOtp()
        {
            var rng = new Random();
            return rng.Next(100000, 999999).ToString();

        }
    }
}
