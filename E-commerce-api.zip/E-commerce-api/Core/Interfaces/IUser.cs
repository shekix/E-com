﻿using Core.Models.User;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IUser
    {
        Task<userRegistrationDto> userRegistration(userRegistrationDto dto);
        Task<bool> userLogin(userLoginDto dto);
        Task<string> userVerification(OtpVerficationDto dto);
    }
}
